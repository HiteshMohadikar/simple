package hitesh.mvc.helper;

import java.sql.Connection;

public class Constants {
	public static Connection con = null;
	public static final String sqlid = "root";
	public static final String sqlpass = "root";
	public static final String sqlurl = "jdbc:mysql://localhost/user";
	
}
