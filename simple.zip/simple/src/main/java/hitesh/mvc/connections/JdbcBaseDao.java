package hitesh.mvc.connections;

import java.sql.Connection;

public class JdbcBaseDao {

	protected Connection con = null;
}
